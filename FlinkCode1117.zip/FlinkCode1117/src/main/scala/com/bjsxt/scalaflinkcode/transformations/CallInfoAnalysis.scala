package com.bjsxt.scalaflinkcode.transformations

import java.text.SimpleDateFormat
import java.util.Date

import com.bjsxt.scalaflinkcode.sources.StationLog
import org.apache.flink.api.common.functions.{MapFunction, RichMapFunction, RuntimeContext}
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment

/**
  * 统计每个人通话开始时间与通话结束时间
  */
object CallInfoAnalysis {
  def main(args: Array[String]): Unit = {
    import org.apache.flink.streaming.api.scala._
    val env: StreamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment
    val lines: DataStream[String] = env.socketTextStream("mynode5",9999)
    val stationDS: DataStream[StationLog] = lines.map(line => {
      val arr: Array[String] = line.split(",")
      StationLog(arr(0), arr(1), arr(2), arr(3), arr(4).toLong, arr(5).toLong)
    })

    val result: DataStream[String] = stationDS.map(new RichMapFunction[StationLog, String] {

      override def map(sl: StationLog): String = {
        val out: String = sl.callOut
        val startTime: Long = sl.callTime
        val dur = sl.dur * 1000
        val format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        s"手机号：${out},通话起始时间:${format.format(new Date(startTime))} - ${format.format(new Date(startTime + dur))}"
      }
    })

//    val result1: DataStream[String] = stationDS.map(new MapFunction[StationLog, String] {
//
//      override def map(sl: StationLog): String = {
//        val out: String = sl.callOut
//        val startTime: Long = sl.callTime
//        val dur = sl.dur * 1000
//        val format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
//        s"手机号：${out},通话起始时间:${format.format(new Date(startTime))} - ${format.format(new Date(startTime + dur))}"
//      }
//    })

//    val result: DataStream[String] = stationDS.map(sl => {
//      val out: String = sl.callOut
//      val startTime: Long = sl.callTime
//      val dur = sl.dur * 1000
//      val format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
//      s"手机号：${out},通话起始时间:${format.format(new Date(startTime))} - ${format.format(new Date(startTime + dur))}"
//    })

    result.print()
    env.execute()
  }

}
