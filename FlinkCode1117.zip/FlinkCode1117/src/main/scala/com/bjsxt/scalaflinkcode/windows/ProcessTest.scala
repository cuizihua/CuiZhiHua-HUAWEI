package com.bjsxt.scalaflinkcode.windows

import java.text.SimpleDateFormat
import java.util.Date

import com.bjsxt.scalaflinkcode.sources.StationLog
import org.apache.flink.streaming.api.functions.KeyedProcessFunction
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.streaming.api.scala.function.ProcessWindowFunction
import org.apache.flink.streaming.api.windowing.time.Time
import org.apache.flink.streaming.api.windowing.windows.TimeWindow
import org.apache.flink.util.Collector

/**
  * 每隔5s统计过去10s ,统计每个基站中通话时间最大的一条数据
  */
object ProcessTest {
  def main(args: Array[String]): Unit = {
    val env: StreamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment
    import org.apache.flink.streaming.api.scala._
    val lines: DataStream[String] = env.socketTextStream("mynode5",9999)

    val stationDS: DataStream[StationLog] = lines.map(line => {
      val arr: Array[String] = line.split(",")
      StationLog(arr(0), arr(1), arr(2), arr(3), arr(4).toLong, arr(5).toLong)
    })

    //process 全量函数
    val result: DataStream[String] = stationDS.keyBy(_.sid)
      .timeWindow(Time.seconds(10), Time.seconds(5))
      .process(new ProcessWindowFunction[StationLog, String, String, TimeWindow] {
        //key : 当前处理数据的key  , context : Flink的上下文 ，elements : 窗口内全部数据 out:回收数据对象
        override def process(key: String, context: Context, elements: Iterable[StationLog], out: Collector[String]): Unit = {

          val head: StationLog = elements.toList.sortWith((sl1, sl2) => {
            sl1.dur > sl2.dur
          }).head

          val format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
          out.collect(s"当前基站：${key}，" +
            s"时间窗口的起始时间:${format.format(new Date(context.window.getStart))}\t${format.format(new Date(context.window.getEnd))}," +
            s"最近10s最大通话时长:${head.dur}")
        }
      })
    result.print()
    env.execute()
  }

}
