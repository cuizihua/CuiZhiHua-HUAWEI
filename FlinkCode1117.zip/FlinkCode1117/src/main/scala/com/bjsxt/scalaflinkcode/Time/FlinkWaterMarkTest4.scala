package com.bjsxt.scalaflinkcode.Time

import com.bjsxt.scalaflinkcode.sources.StationLog
import org.apache.flink.api.common.functions.ReduceFunction
import org.apache.flink.streaming.api.TimeCharacteristic
import org.apache.flink.streaming.api.functions.timestamps.BoundedOutOfOrdernessTimestampExtractor
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.streaming.api.windowing.time.Time

/**
  *  Flink allowedLateness  延迟数据处理机制：
  *   在使用watermark 基础之上，还有延迟更长时间的数据，如果我们想要处理这些延迟更长的数据，可以使用延迟数据处理的机制。
  *
  */
object FlinkWaterMarkTest4 {
  def main(args: Array[String]): Unit = {
    val env: StreamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment
    import org.apache.flink.streaming.api.scala._
    //并行度设置为1
    env.setParallelism(1)
    //指定使用事件时间
    env.setStreamTimeCharacteristic(TimeCharacteristic.EventTime)

    val ds: DataStream[String] = env.socketTextStream("mynode5",9999)
    val ds2: DataStream[StationLog] = ds.map(line => {
      val arr: Array[String] = line.split(",")
      StationLog(arr(0), arr(1), arr(2), arr(3), arr(4).toLong, arr(5).toLong)
    })
    //设置watermark
    val ds3 = ds2.assignTimestampsAndWatermarks(new BoundedOutOfOrdernessTimestampExtractor[StationLog](Time.seconds(3)) {
      //抽取事件的时间 ，elements : 当前事件
      override def extractTimestamp(element: StationLog): Long = element.callTime
    })

    //设置迟到太久的数据标签
   val lateData= new OutputTag[StationLog]("late-data")

    //对ds3使用window
    val result: DataStream[StationLog] = ds3.keyBy(_.sid)
      .timeWindow(Time.seconds(5))
      .sideOutputLateData(lateData)
      .allowedLateness(Time.seconds(3))
      .reduce(new ReduceFunction[StationLog] {
        override def reduce(value1: StationLog, value2: StationLog): StationLog = {
          StationLog(value1.sid, value1.callOut, value1.callIn, value1.callType, value1.callTime, value1.dur + value2.dur)
        }
      })
    result.print()
    result.getSideOutput(lateData).print("迟到数据：")

    env.execute()
  }
}
