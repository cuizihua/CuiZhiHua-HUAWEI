package com.bjsxt.scalaflinkcode.transformations

import java.sql.{Connection, DriverManager, PreparedStatement, ResultSet}

import com.bjsxt.scalaflinkcode.sources.StationLog
import org.apache.flink.api.common.functions.RichMapFunction
import org.apache.flink.configuration.Configuration
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment

/**
  * 根据每条流式数据的通话记录，统计每个通话人的姓名，及通话时长
  */
object CallInfoAnalysis2 {
  def main(args: Array[String]): Unit = {
    val env: StreamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment
    import org.apache.flink.streaming.api.scala._

    val lines: DataStream[String] = env.socketTextStream("mynode5",9999)
    val stationLogInfo: DataStream[StationLog] = lines.map(line => {
      val arr: Array[String] = line.split(",")
      StationLog(arr(0), arr(1), arr(2), arr(3), arr(4).toLong, arr(5).toLong)
    })

    val result: DataStream[String] = stationLogInfo.map(new RichMapFunction[StationLog, String] {
      //声明对象
      var conn: Connection = _
      var pst: PreparedStatement = _

      //初始化 当前RichMapFunction调用一次
      override def open(parameters: Configuration): Unit = {
        conn = DriverManager.getConnection("jdbc:mysql://192.168.179.14:3306/flinktest", "root", "123456")
        pst = conn.prepareStatement("select phone_num ,name,address from phone_num_Info where phone_num = ?")
      }

      //来一条数据调用一次
      override def map(value: StationLog): String = {
        val sid: String = value.sid
        val out: String = value.callOut
        val in: String = value.callIn
        val callType: String = value.callType
        val time: Long = value.callTime
        val dur: Long = value.dur
        pst.setString(1, out)
        val set: ResultSet = pst.executeQuery()
        var callName = ""
        var callAddress = ""
        while (set.next()) {
          callName = set.getString(2)
          callAddress = set.getString(3)
        }

        pst.setString(1, in)
        val set1: ResultSet = pst.executeQuery()
        var calledName = ""
        var calledAddress = ""
        while (set1.next()) {
          calledName = set1.getString(2)
          calledAddress = set1.getString("address")
        }

        s"基站ID:${sid},主叫：${callName}，主叫地址:${callAddress},被叫:${calledName},被叫地址:${calledAddress},通话时长:${dur}"
      }

      //程序失败或者取消时调用
      override def close(): Unit = {
        pst.close()
        conn.close()
      }
    })

    result.print()
    env.execute()
  }

}
