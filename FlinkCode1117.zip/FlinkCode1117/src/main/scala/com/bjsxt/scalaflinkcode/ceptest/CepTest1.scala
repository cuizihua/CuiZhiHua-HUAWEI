package com.bjsxt.scalaflinkcode.ceptest

import java.util

import org.apache.flink.cep.PatternSelectFunction
import org.apache.flink.cep.scala.{CEP, PatternStream}
import org.apache.flink.cep.scala.pattern.Pattern
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.streaming.api.windowing.time.Time

/**
  * CEP 复杂事件编程步骤：
  *   1.定义获取数据流
  *   2.定义模式
  *   3.将模式应用到数据流中
  *   4.选择结果
  */
object CepTest1 {
  def main(args: Array[String]): Unit = {
    val env: StreamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment
    import org.apache.flink.streaming.api.scala._

    //1.获取数据流
    val lines: DataStream[String] = env.socketTextStream("mynode5",9999)

    //2.定义模式
    val pattern: Pattern[String, String] =
//      Pattern.begin[String]("first").where(s=>{s.length == 3}).times(2,4).greedy
      Pattern.begin[String]("first").where(s=>{s.startsWith("a")})
      .next("second").where(s=>{s.startsWith("b")})//严格邻近
//      .followedBy("second").where(s=>{s.startsWith("b")})//宽松邻近
//      .followedByAny("second").where(s=>{s.startsWith("b")})//非确定宽松邻近
      .within(Time.seconds(5))

    //3.将模式应用到数据流中
    val ps: PatternStream[String] = CEP.pattern(lines, pattern)

    //4.选择结果
    val resultDS: DataStream[String] = ps.select(new PatternSelectFunction[String, String] {
      // pattern : 匹配上的事件Map
      override def select(pattern: util.Map[String, util.List[String]]): String = {
        val firstListStr: String = pattern.getOrDefault("first",new util.ArrayList[String]()).toString
        val secondListStr: String = pattern.getOrDefault("second",new util.ArrayList[String]()).toString
        "frist:"+firstListStr+"\tsecond:"+secondListStr
      }
    })

    resultDS.print()
    env.execute()




  }

}
