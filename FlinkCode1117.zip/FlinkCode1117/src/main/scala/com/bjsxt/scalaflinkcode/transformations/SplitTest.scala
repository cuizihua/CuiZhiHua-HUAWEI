package com.bjsxt.scalaflinkcode.transformations

import java.{lang, util}

import org.apache.flink.streaming.api.collector.selector.OutputSelector
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment

/**
  * split 切分流
  */
object SplitTest {
  def main(args: Array[String]): Unit = {
    val env  = StreamExecutionEnvironment.getExecutionEnvironment
    import org.apache.flink.streaming.api.scala._
    val ds1: DataStream[Int] = env.fromCollection(Array[Int](
      1, 2, 3, 4, 5, 6, 7, 8, 9
    ))

    //split
    val result: SplitStream[Int] = ds1.split(new OutputSelector[Int] {
      override def select(value: Int): lang.Iterable[String] = {
        if (value >= 5) {
          val list = new util.ArrayList[String]()
          list.add("xx1")
          list
        } else {
          val list = new util.ArrayList[String]()
          list.add("xx2")
          list
        }
      }
    })

//    result.select("xx1").print()

    result.select("xx2").print()
    env.execute()
  }

}
