package com.bjsxt.scalaflinkcode.sources

import org.apache.flink.streaming.api.functions.source.SourceFunction
import org.apache.flink.streaming.api.scala.{DataStream, StreamExecutionEnvironment}

import scala.util.Random

/**
  * 自定义非并行Source
  *   1).自定义Source需要实现 SourceFunction[T]
  *   2).使用ctx.collect()发送数据
  */

//自定义source
class MyDefinedSource extends SourceFunction[StationLog]{
  var stop  = false
  //Source 产生数据,一般使用一个循环一直产生数据
  override def run(ctx: SourceFunction.SourceContext[StationLog]): Unit = {
    val random = new Random()
    val array = Array[String]("success","fail","barring","busy")
    while(!stop){
      1.to(10).map(one=>{
        val sl = StationLog("sid_"+one,"181"+random.nextInt(10000000).formatted("%08d"),
          "191"+random.nextInt(10000000).formatted("%08d"),array(random.nextInt(4)),System.currentTimeMillis(),random.nextInt(100))

        //发送数据
        ctx.collect(sl)
      })
      Thread.sleep(1000*10)
    }
  }

  //当任务取消时调用的方法
  override def cancel(): Unit = {
    stop = true
  }
}

object SelfDefindedSource {
  def main(args: Array[String]): Unit = {
    import org.apache.flink.streaming.api.scala._
    val env: StreamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment
    val ds: DataStream[StationLog] = env.addSource(new MyDefinedSource())

    ds.print()
    env.execute()
  }
}
