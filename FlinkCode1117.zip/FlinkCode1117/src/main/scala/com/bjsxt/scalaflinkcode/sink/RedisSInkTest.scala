package com.bjsxt.scalaflinkcode.sink

import org.apache.flink.streaming.api.scala.{DataStream, StreamExecutionEnvironment}
import org.apache.flink.streaming.connectors.redis.RedisSink
import org.apache.flink.streaming.connectors.redis.common.config.FlinkJedisPoolConfig
import org.apache.flink.streaming.connectors.redis.common.mapper.{RedisCommand, RedisCommandDescription, RedisMapper}
/**
  *  读取socket数据写入redis
  *  HSET K,V(K,V)
  */
object RedisSInkTest {
  def main(args: Array[String]): Unit = {
    import org.apache.flink.streaming.api.scala._
    val env: StreamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment
    val lines: DataStream[String] = env.socketTextStream("mynode5",9999)

    val result: DataStream[(String, Int)] = lines.flatMap(line => {
      line.split(" ")
    })
      .map(word => {
        (word, 1)
      })
      .keyBy(0)
      .sum(1)

    //将结果存入redis中
    //创建Redis配置
    val config: FlinkJedisPoolConfig = new FlinkJedisPoolConfig.Builder().setDatabase(1).setHost("mynode4").setPort(6379).build()
    result.addSink(new RedisSink[(String, Int)](config,new RedisMapper[(String, Int)] {
      //设置redis存储数据模式，test 设置redis hset key
      override def getCommandDescription: RedisCommandDescription =
        new RedisCommandDescription(RedisCommand.HSET,"test")

      //设置 value 的key
      override def getKeyFromData(data: (String, Int)): String = data._1

      //设置value 的value
      override def getValueFromData(data: (String, Int)): String = data._2.toString
    }))

    env.execute()
  }

}
