package com.bjsxt.scalaflinkcode.transformations

import org.apache.flink.contrib.streaming.state.RocksDBStateBackend
import org.apache.flink.runtime.state.filesystem.FsStateBackend
import org.apache.flink.runtime.state.memory.MemoryStateBackend
import org.apache.flink.streaming.api.CheckpointingMode
import org.apache.flink.streaming.api.environment.CheckpointConfig
import org.apache.flink.streaming.api.environment.CheckpointConfig.ExternalizedCheckpointCleanup
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment

object CheckPointTest {
  def main(args: Array[String]): Unit = {
    val env: StreamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment
    import org.apache.flink.streaming.api.scala._

    //开启checkpoint
    env.enableCheckpointing(5000)
    //设置数据处理模式： Exactly_once - 精准一次消费 ，at_least_once - 至少消费一次数据
    env.getCheckpointConfig.setCheckpointingMode(CheckpointingMode.EXACTLY_ONCE)

    //设置checkpoint 最大的执行并行个数
    env.getCheckpointConfig.setMaxConcurrentCheckpoints(2)

    //当程序被人为取消时，要不要保存状态
    env.getCheckpointConfig.enableExternalizedCheckpoints(ExternalizedCheckpointCleanup.RETAIN_ON_CANCELLATION)

    //设置状态保存到哪里
//    env.setStateBackend(new MemoryStateBackend(10*1024*1024))
//    env.setStateBackend(new FsStateBackend("hdfs://mycluster/flink/sss"))
//    env.setStateBackend(new RocksDBStateBackend("hdfs://mycluster/flink/sss"))







    val ds: DataStream[String] = env.socketTextStream("mynode5",9999)
    ds.flatMap(line=>{line.split(" ")})
      .map((_,1))
      .keyBy(0)
      .sum(1)
      .print()

    env.execute()
  }

}
