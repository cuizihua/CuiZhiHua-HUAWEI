package com.bjsxt.scalaflinkcode.flinksqltest

import com.bjsxt.scalaflinkcode.sources.StationLog
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.table.api.{EnvironmentSettings, Table}
import org.apache.flink.table.api.scala.StreamTableEnvironment
import org.apache.flink.types.Row

/**
  *  读取DataStream 中的数据加载Table 对象
  */
object FlinkTableTest2 {
  def main(args: Array[String]): Unit = {
    val env: StreamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment
    import org.apache.flink.streaming.api.scala._
    val settings = EnvironmentSettings.newInstance().inStreamingMode().useOldPlanner().build()
    val tableEnv: StreamTableEnvironment = StreamTableEnvironment.create(env,settings)

    //读取Scoket数据 加载DataStream
    val ds1: DataStream[String] = env.socketTextStream("mynode5",9999)

    val ds2: DataStream[StationLog] = ds1.map(line => {
      val arr: Array[String] = line.split(",")
      StationLog(arr(0), arr(1), arr(2), arr(3), arr(4).toLong, arr(5).toLong)
    })

    //加载DataStream 获取Table 对象
    import org.apache.flink.table.api.scala._
    val table1: Table = tableEnv.fromDataStream(ds2,'station_id,'call_out,'call_in,'call_type,'call_time,'call_dur)

    //分组聚合
    val table2: Table = table1.groupBy('station_id).select('station_id,'call_dur.sum as 'total_dur)

//    val resultDS: DataStream[Row] = tableEnv.toAppendStream[Row](table2)
    val resultDS: DataStream[(Boolean, Row)] = tableEnv.toRetractStream[Row](table2)
    resultDS.filter(tp=>{tp._1.equals(true)}).print()
    env.execute()




//    table1.printSchema()
    //查询数据
//    val table2: Table = table1.select('station_id, 'call_out, 'call_in, 'call_type, 'call_time, 'call_dur)
//      .filter('call_dur > 20)
//      .where('call_type === "success")

//    tableEnv.toAppendStream[Row](table2).print()
//
//    env.execute()



  }

}
