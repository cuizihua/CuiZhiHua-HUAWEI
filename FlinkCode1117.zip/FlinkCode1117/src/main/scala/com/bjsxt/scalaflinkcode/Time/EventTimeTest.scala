package com.bjsxt.scalaflinkcode.Time

import com.bjsxt.scalaflinkcode.sources.StationLog
import org.apache.flink.streaming.api.TimeCharacteristic
import org.apache.flink.streaming.api.scala.{DataStream, StreamExecutionEnvironment}
import org.apache.flink.streaming.api.windowing.time.Time

/**
  *  Flink 读取Socket数据，使用EventTime
  *   需求：每隔5s 统计一次基站的通话总时长
  */
object EventTimeTest {
  def main(args: Array[String]): Unit = {
    val env: StreamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment
    env.setParallelism(1)
    import org.apache.flink.streaming.api.scala._
    //指定程序处理使用事件时间
    env.setStreamTimeCharacteristic(TimeCharacteristic.EventTime)

    val lines: DataStream[String] = env.socketTextStream("mynode5",9999)
    val ds1: DataStream[StationLog] = lines.map(line => {
      val arr: Array[String] = line.split(",")
      StationLog(arr(0), arr(1), arr(2), arr(3), arr(4).toLong, arr(5).toLong)
    }).assignAscendingTimestamps(sl => {
      sl.callTime
    })

    ds1.keyBy(_.sid).timeWindow(Time.seconds(5)).sum("dur").print()

    env.execute()
  }

}
