package com.bjsxt.scalaflinkcode.Time

import com.bjsxt.scalaflinkcode.sources.StationLog
import org.apache.flink.api.common.functions.ReduceFunction
import org.apache.flink.streaming.api.TimeCharacteristic
import org.apache.flink.streaming.api.functions.AssignerWithPeriodicWatermarks
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.streaming.api.watermark.Watermark
import org.apache.flink.streaming.api.windowing.time.Time

/**
  * 在乱序事件中引入watermark
  *   1.周期性计算watermark ,默认每隔100ms 计算一次watermark
  *   2.非周期性计算watermark
  *
  *   本案例是周期性计算watermark
  * 需求：统计每个基站，每5通话的总时长
  */
object FlinkWaterMarkTest1 {
  def main(args: Array[String]): Unit = {
    val env: StreamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment
    import org.apache.flink.streaming.api.scala._
    //并行度设置为1
    env.setParallelism(1)
    //指定使用事件时间
    env.setStreamTimeCharacteristic(TimeCharacteristic.EventTime)

    val ds: DataStream[String] = env.socketTextStream("mynode5",9999)
    val ds2: DataStream[StationLog] = ds.map(line => {
      val arr: Array[String] = line.split(",")
      StationLog(arr(0), arr(1), arr(2), arr(3), arr(4).toLong, arr(5).toLong)
    })
    //设置watermark
    val ds3: DataStream[StationLog] = ds2.assignTimestampsAndWatermarks(new AssignerWithPeriodicWatermarks[StationLog] {
      //指定事件的延迟时间
      val lateTime = 3000
      //定义事件的最大时间
      var maxEventTime = 0L

      /**
        * 获取 watermark,每隔100ms 计算一次。
        * watermark = 当前到达的事件最大时间 - 延迟时间
        */
      override def getCurrentWatermark: Watermark = {
        new Watermark(maxEventTime - lateTime)
      }

      //指定事件时间 ，element: 当前本条数据， previousElementTimestamp：前一个事件的时间戳
      override def extractTimestamp(element: StationLog, previousElementTimestamp: Long): Long = {
        maxEventTime = maxEventTime.max(element.callTime)
        element.callTime
      }
    })

    //对ds3使用window
    val result: DataStream[StationLog] = ds3.keyBy(_.sid)
      .timeWindow(Time.seconds(5))
      .reduce(new ReduceFunction[StationLog] {
        override def reduce(value1: StationLog, value2: StationLog): StationLog = {
          StationLog(value1.sid, value1.callOut, value1.callIn, value1.callType, value1.callTime, value1.dur + value2.dur)
        }
      })
    result.print()

    env.execute()

  }

}
