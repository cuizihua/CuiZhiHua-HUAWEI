package com.bjsxt.scalaflinkcode

import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment

/**
  * Flink处理流式数据
  *   1.Flink 流式处理底层对象是DataStream
  *   2.Flink 批数据处理中分组使用groupBy ，流式处理中分组使用keyBy
  *   3.Flink处理数据流程
  *     1).创建Flink环境：
  *       批数据处理：ExecutionEnvironment.getExecutionEnvironment()
  *       流式处理：StreamExecutionEnvironment.getExecutionEnvironment
  *     2.读取数据源Source
  *     3.使用算子转换数据
  *     4.使用evn.executor触发执行（在批数据处理中不需要，默认批数据处理中print自带触发）
  *
  *  4.本地默认执行的并行度与本机core的个数相同，也可以env.setParallelism(1)设置并行度
  *
  */
object FlinkStreamWC {
  def main(args: Array[String]): Unit = {
    //1.创建Flink 流式处理环境
    val env: StreamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment
    //2.导入隐式包
    import org.apache.flink.streaming.api.scala._
    //3.读取socket中的数据
    val lines: DataStream[String] = env.socketTextStream("mynode5", 9999)
    //4.进行数据转换
    val words: DataStream[String] = lines.flatMap(line => {
      line.split(" ")
    })
    val pairWords: DataStream[(String, Int)] = words.map(word => {
      (word, 1)
    })
    pairWords.keyBy(0).sum(1).print()

    //5.触发执行
    env.execute()

  }
}
