package com.bjsxt.scalaflinkcode.ceptest

import java.util

import org.apache.flink.cep.{PatternSelectFunction, PatternTimeoutFunction}
import org.apache.flink.cep.scala.CEP
import org.apache.flink.cep.scala.pattern.Pattern
import org.apache.flink.streaming.api.TimeCharacteristic
import org.apache.flink.streaming.api.functions.timestamps.BoundedOutOfOrdernessTimestampExtractor
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.streaming.api.windowing.time.Time


/**
  *  使用Flink cep 实现事件监控
  *   如果一个用户下了订单，在10分钟之内支付订单，返回发货信息，如果用户在10分钟之内没有支付，则发出支付超时，取消订单信息
  */
case class OrderInfo(uid:String,orderTime:Long,orderType:String)
object CepTest3 {
  def main(args: Array[String]): Unit = {
    val env: StreamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment
    import org.apache.flink.streaming.api.scala._

    env.setParallelism(1)
    env.setStreamTimeCharacteristic(TimeCharacteristic.EventTime)
    //1.获取数据流
    val lines: DataStream[String] = env.socketTextStream("mynode5", 9999)
    val logDS: DataStream[OrderInfo] = lines.map(line => {
      val arr: Array[String] = line.split(",")
      OrderInfo(arr(0), arr(1).toLong, arr(2))
    }).assignTimestampsAndWatermarks(new BoundedOutOfOrdernessTimestampExtractor[OrderInfo](Time.seconds(3)) {
      override def extractTimestamp(element: OrderInfo): Long = element.orderTime
    })

    //定义模式
    val pattern: Pattern[OrderInfo, OrderInfo] =
      Pattern.begin[OrderInfo]("first").where(_.orderType.equals("ordered"))
      .followedBy("second").where(_.orderType.equals("pay"))
      .within(Time.seconds(10))

    //定义超时时间的tag
    val tag: OutputTag[String] = new OutputTag[String]("late-data")
    //应用模式
    val resultDS: DataStream[String] = CEP.pattern(logDS.keyBy(_.uid), pattern).select(tag, new PatternTimeoutFunction[OrderInfo, String] {
      override def timeout(pattern: util.Map[String, util.List[OrderInfo]], timeoutTimestamp: Long): String = {
        val info: OrderInfo = pattern.get("first").iterator().next()
        s"订单超时：用户：${info.uid}，下单时间:${info.orderTime},15分钟没有付款，订单取消"
      }
    }, new PatternSelectFunction[OrderInfo, String] {
      //正常待发货事件
      override def select(pattern: util.Map[String, util.List[OrderInfo]]): String = {
        val firstList: util.List[OrderInfo] = pattern.getOrDefault("first", new util.ArrayList[OrderInfo]())
        val secondList: util.List[OrderInfo] = pattern.getOrDefault("second", new util.ArrayList[OrderInfo]())
        val orderInfo: OrderInfo = firstList.iterator().next()
        val payInfo: OrderInfo = secondList.iterator().next()
        s"待发货：用户：${orderInfo.uid} 下单时间:${orderInfo.orderTime},付款时间：${payInfo.orderTime}"
      }
    })
    //打印正常信息：
    resultDS.print()
    //打印超时信息：
    resultDS.getSideOutput(tag).print()

    env.execute()
  }

}
