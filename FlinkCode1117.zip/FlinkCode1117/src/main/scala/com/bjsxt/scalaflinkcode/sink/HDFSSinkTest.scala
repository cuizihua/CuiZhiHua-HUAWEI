package com.bjsxt.scalaflinkcode.sink

import com.bjsxt.scalaflinkcode.sources.{MyDefinedSource, StationLog}
import org.apache.flink.api.common.serialization.SimpleStringEncoder
import org.apache.flink.core.fs.Path
import org.apache.flink.streaming.api.functions.sink.filesystem.StreamingFileSink
import org.apache.flink.streaming.api.functions.sink.filesystem.rollingpolicies.DefaultRollingPolicy
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment

/**
  *  HDFS sink
  *   1).pom.xml导包
  *   2).生成文件策略
  */
object HDFSSinkTest {
  def main(args: Array[String]): Unit = {
    val env: StreamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment
    import org.apache.flink.streaming.api.scala._

    //设置并行度1
    env.setParallelism(1)

//    val ds2: DataStream[String] = env.socketTextStream("mynode5",9999)
    val ds: DataStream[StationLog] = env.addSource(new MyDefinedSource())
    val ds2: DataStream[String] = ds.map(sl => {
      sl.toString
    })

    /**
      * sink 到 hdfs
      */
      //定义在桶内生成文件的滚动策略
    val policy: DefaultRollingPolicy[String, String] = DefaultRollingPolicy.create()
        .withInactivityInterval(1000 * 200000) //设置文件不活动的时长，默认一分钟
        .withMaxPartSize(1024*1024*128) //生成的一个数据文件最大值 ，默认128M
        .withRolloverInterval(1000) //设置文件自动生成周期，默认1分钟
        .build[String, String]()

    //定义HDFS Sink
    val hdfsSink: StreamingFileSink[String] = StreamingFileSink.forRowFormat[String](
      new Path("hdfs://mycluster/flink/result/"),
      new SimpleStringEncoder[String]("utf-8")
    ).withBucketCheckInterval(10) //检查生成HDFS文件的周期，默认是1分钟，每小时都生成一个目录（bucket）
      .withRollingPolicy(policy) //在桶内（bucket）中生成数据文件的滚动策略
      .build()


    ds2.addSink(hdfsSink)
    ds2.print()
    env.execute()

  }

}
