package com.bjsxt.scalaflinkcode.flinksqltest

import org.apache.flink.api.scala.typeutils.Types
import org.apache.flink.streaming.api.scala.{DataStream, StreamExecutionEnvironment}
import org.apache.flink.table.api.{EnvironmentSettings, Table}
import org.apache.flink.table.api.scala.StreamTableEnvironment
import org.apache.flink.table.sources.CsvTableSource
import org.apache.flink.types.Row

/**
  *  如何准备Flink Table环境及对象
  */
object FlinkTableTest1 {
  def main(args: Array[String]): Unit = {
    val env: StreamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment
    import org.apache.flink.streaming.api.scala._
    val settings = EnvironmentSettings.newInstance().inStreamingMode().useOldPlanner().build()

    //获取table处理环境
    val tableEnv: StreamTableEnvironment = StreamTableEnvironment.create(env,settings)

    //读取CSV格式数据加载一个Table对象
    val table1: Table = tableEnv.fromTableSource(new CsvTableSource("./data/station_log",
      Array[String]("station_id", "call_out", "call_in", "call_type", "call_time", "call_dur"),
      Array(Types.STRING, Types.STRING, Types.STRING, Types.STRING, Types.LONG, Types.LONG)
    ))

    import org.apache.flink.table.api.scala._

    //使用table api 做查询
    val table2: Table = table1.select('station_id,'call_out,'call_in,'call_type,'call_time,'call_dur)

    //打印schema 信息
    table2.printSchema()

    //将Table 对象转换成DataStream之后再输出
    val resultDs: DataStream[Row] = tableEnv.toAppendStream[Row](table2)

    resultDs.print()

    env.execute()



  }

}
