package com.bjsxt.scalaflinkcode.ceptest

import java.util

import org.apache.flink.cep.PatternSelectFunction
import org.apache.flink.cep.scala.{CEP, PatternStream}
import org.apache.flink.cep.scala.pattern.Pattern
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment

/**
  *  uid1,xxxx,success
  *  uid2,xxxx,fail
  */

case class LogInfo(uid:String,logTime:Long,logType:String)
object CepTest2 {
  def main(args: Array[String]): Unit = {
    val env: StreamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment
    import org.apache.flink.streaming.api.scala._
    //1.获取数据流
    val lines: DataStream[String] = env.socketTextStream("mynode5",9999)
    val logDS: DataStream[LogInfo] = lines.map(line => {
      val arr: Array[String] = line.split(",")
      LogInfo(arr(0), arr(1).toLong, arr(2))
    })
    //定义模式
    val pattern: Pattern[LogInfo, LogInfo] = Pattern.begin[LogInfo]("first").where(loginfo => {
      loginfo.logType.equals("fail")
    })
      .next("second").where(loginfo => {
      loginfo.logType.equals("fail")
    })
      .next("third").where(loginfo => {
      loginfo.logType.equals("fail")
    })


    //模式应用到数据流中
    val ps: PatternStream[LogInfo] = CEP.pattern(logDS.keyBy(_.uid),pattern)

    //选择结果
    val result: DataStream[String] = ps.select(new PatternSelectFunction[LogInfo, String] {
      override def select(pattern: util.Map[String, util.List[LogInfo]]): String = {
        val firstList: util.List[LogInfo] = pattern.getOrDefault("first", new util.ArrayList[LogInfo]())
        val secondList: util.List[LogInfo] = pattern.getOrDefault("second", new util.ArrayList[LogInfo]())
        val thirdList: util.List[LogInfo] = pattern.getOrDefault("third", new util.ArrayList[LogInfo]())
        val str = new StringBuilder()
        import scala.collection.JavaConverters._
        str.append("涉嫌恶意登录：first:")
        for (elem <- firstList.asScala.toList) {
          str.append(elem + ",")
        }
        str.append("|second:")
        for (elem <- secondList.asScala.toList) {
          str.append(elem + ",")
        }
        str.append("|third:")
        for (elem <- thirdList.asScala.toList) {
          str.append(elem + ",")
        }
        str.toString()
      }
    })
    result.print()
    env.execute()
  }

}
