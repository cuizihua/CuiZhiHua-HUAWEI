package com.bjsxt.scalaflinkcode.flinksqltest

import com.bjsxt.scalaflinkcode.sources.StationLog
import org.apache.flink.streaming.api.TimeCharacteristic
import org.apache.flink.streaming.api.functions.timestamps.BoundedOutOfOrdernessTimestampExtractor
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.streaming.api.windowing.time.Time
import org.apache.flink.table.api.EnvironmentSettings
import org.apache.flink.table.api.scala.StreamTableEnvironment
import org.apache.flink.types.Row

object FlinkSQLTest2 {
  def main(args: Array[String]): Unit = {
    val env: StreamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment
    env.setParallelism(1)
    env.setStreamTimeCharacteristic(TimeCharacteristic.EventTime)
    import org.apache.flink.streaming.api.scala._
    val settings = EnvironmentSettings.newInstance().useOldPlanner().inStreamingMode().build()
    val tableEnv: StreamTableEnvironment = StreamTableEnvironment.create(env,settings)

    val ds1: DataStream[String] = env.socketTextStream("mynode5",9999)
    val ds2: DataStream[StationLog] = ds1.map(line => {
      val arr: Array[String] = line.split(",")
      StationLog(arr(0), arr(1), arr(2), arr(3), arr(4).toLong, arr(5).toLong)
    }).assignTimestampsAndWatermarks(new BoundedOutOfOrdernessTimestampExtractor[StationLog](Time.seconds(3)) {
      override def extractTimestamp(element: StationLog): Long = element.callTime
    })

    //注册成表
    import org.apache.flink.table.api.scala._
    tableEnv.registerDataStream("temp",ds2,'station_id,'call_out,'call_in,'call_type,'call_time.rowtime,'call_dur)

    //编写sql语句
    val table1 = tableEnv.sqlQuery(
      """
        | select
        |   hop_start(call_time,interval '5' second,interval '10' second ),
        |   hop_end(call_time,interval '5' second,interval '10' second ),
        |   station_id,
        |   count(*) as total_count
        |from temp
        |group by station_id ,
        | hop(call_time,interval '5' second,interval '10' second )
      """.stripMargin)
    //滑动窗口

    //滚动窗口
//    val table1 = tableEnv.sqlQuery(
//      """
//        | select tumble_start(call_time,interval '5' second ),tumble_end(call_time,interval '5' second )
//        | station_id,count(*) as total_count from temp group by station_id ,tumble(call_time,interval '5' second )
//      """.stripMargin)


    val resultds: DataStream[(Boolean, Row)] = tableEnv.toRetractStream[Row](table1)
    resultds.filter(_._1.equals(true)).map(_._2).print()
    env.execute()

  }

}
