package com.bjsxt.scalaflinkcode.flinksqltest

import com.bjsxt.scalaflinkcode.sources.StationLog
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.table.api.EnvironmentSettings
import org.apache.flink.table.api.scala.StreamTableEnvironment
import org.apache.flink.types.Row

/**
  * 使用sql语句处理数据
  */
object FlinkSQLTest1 {
  def main(args: Array[String]): Unit = {
    val env: StreamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment
    import org.apache.flink.streaming.api.scala._
    val settings = EnvironmentSettings.newInstance().useOldPlanner().inStreamingMode().build()
    val tableEnv: StreamTableEnvironment = StreamTableEnvironment.create(env,settings)

    val ds1: DataStream[String] = env.socketTextStream("mynode5",9999)
    val ds2: DataStream[StationLog] = ds1.map(line => {
      val arr: Array[String] = line.split(",")
      StationLog(arr(0), arr(1), arr(2), arr(3), arr(4).toLong, arr(5).toLong)
    })

    //将DataStream注册成表
    tableEnv.registerDataStream("temp",ds2)
    //编写sql处理数据
    val table1 = tableEnv.sqlQuery(
      """
        | select sid ,count(*) as totalcount from temp group by sid
      """.stripMargin)

    val resultDS: DataStream[(Boolean, Row)] = tableEnv.toRetractStream[Row](table1)
    resultDS.print()
    env.execute()
  }

}
