package com.bjsxt.scalaflinkcode.windows

import com.bjsxt.scalaflinkcode.sources.StationLog
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.streaming.api.windowing.windows.GlobalWindow

/**
  * count window - 计数窗口
  *   每当有指定个数的元素时，就会触发窗口
  */
object CountWindowTest {
  def main(args: Array[String]): Unit = {
    val env: StreamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment
    import org.apache.flink.streaming.api.scala._
    val lines: DataStream[String] = env.socketTextStream("mynode5",9999)

    val stationDS: DataStream[StationLog] = lines.map(line => {
      val arr: Array[String] = line.split(",")
      StationLog(arr(0), arr(1), arr(2), arr(3), arr(4).toLong, arr(5).toLong)
    })

    //针对 keyedDataStream使用 count滑动窗口
    stationDS.keyBy(0).countWindow(5,2)
      .sum("dur").print()

//    //针对 keyedDataStream使用 count滚动窗口
//    stationDS.keyBy(0).countWindow(5)
//        .sum("dur").print()



    //针对没有key DataStream使用 count滚动窗口
//    val windows: AllWindowedStream[String, GlobalWindow] = lines.countWindowAll(5)
//    windows.reduce((s1,s2)=>{s1+"$"+s2}).print()
    env.execute()

  }

}
