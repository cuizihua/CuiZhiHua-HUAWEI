package com.bjsxt.scalaflinkcode.transformations

import com.bjsxt.scalaflinkcode.sources.StationLog
import org.apache.flink.streaming.api.functions.co.{CoFlatMapFunction, CoMapFunction}
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.util.Collector

/**
  *  union : 连接多个流，这两个流类型必须一致
  *  connect : 连接两个流，这两个流类型可以不一致
  */
object UnionTest {
  def main(args: Array[String]): Unit = {
    val env: StreamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment
    env.setParallelism(1)
    import org.apache.flink.streaming.api.scala._

    val ds1: DataStream[Int] = env.fromCollection(Array[Int](
      1,2,3,4,5,6
    ))
    val ds2: DataStream[String] = env.fromCollection(Array[String](
      "hello java","flink spark"
    ))

    //connect
    val result: DataStream[String] = ds1.connect(ds2).flatMap(new CoFlatMapFunction[Int, String, String] {
      override def flatMap1(value: Int, out: Collector[String]): Unit = {
        out.collect(value + "#")
      }

      override def flatMap2(value: String, out: Collector[String]): Unit = {
        val arr: Array[String] = value.split(" ")
        arr.foreach(one => {
          out.collect(one + "#")
        })
      }
    })

//    val result: DataStream[String] = ds1.connect(ds2).map((i:Int)=>{i+"#"},(s:String)=>{s+"#"})

//    val result: DataStream[String] = ds1.connect(ds2).map(new CoMapFunction[Int, String, String] {
//      //针对第一个流进行处理方法，需要对每条数据得到 String类型数据
//      override def map1(value: Int): String = value + "#"
//
//      //针对第二个流进行处理方法，需要对每条数据得到 String类型数据
//      override def map2(value: String): String = value + "#"
//    })
    result.print()
    env.execute()

    //union :
//    ds1.union(ds2).print()
//    env.execute()



  }

}
