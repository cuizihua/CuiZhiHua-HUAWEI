package com.bjsxt.scalaflinkcode.sources

import java.util.Properties

import org.apache.flink.api.common.typeinfo.TypeInformation
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.streaming.connectors.kafka.{FlinkKafkaConsumer, KafkaDeserializationSchema}
import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.flink.streaming.api.scala._
/**
  *  读取Kafka 中的数据，读取key 读取value
  */

class MyKafkaSource extends  KafkaDeserializationSchema[(String, String)] {
  //是否流结束
  override def isEndOfStream(nextElement: (String, String)): Boolean = false

  //解析从Kafka中获取的数据
  override def deserialize(record: ConsumerRecord[Array[Byte], Array[Byte]]): (String, String) = {
  val key: String = new String(record.key())
  val value: String = new String(record.value())
  (key, value)
  }

  //指定从kafka中读取数据的格式
  override def getProducedType: TypeInformation[(String, String)] = {
    createTuple2TypeInformation[String,String](createTypeInformation[String], createTypeInformation[String])
  }
}

object FlinkSourceKafka2 {
  def main(args: Array[String]): Unit = {
    val env: StreamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment

    //kafka连接配置
    val props = new Properties()
    props.setProperty("bootstrap.servers","mynode1:9092,mynode2:9092,mynode3:9092")
    props.setProperty("key.deserializer",classOf[StringDeserializer].getName)
    props.setProperty("value.deserializer",classOf[StringDeserializer].getName)
    props.setProperty("group.id","group11192")

    //读取Kafka key value格式数据
    val lines: DataStream[(String, String)] = env.addSource(new FlinkKafkaConsumer[(String, String)]("flinktest1",new MyKafkaSource(), props))

    lines.print()
    env.execute()
  }

}
