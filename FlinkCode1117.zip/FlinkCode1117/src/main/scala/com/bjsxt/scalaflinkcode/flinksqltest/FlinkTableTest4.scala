package com.bjsxt.scalaflinkcode.flinksqltest

import com.bjsxt.scalaflinkcode.sources.StationLog
import org.apache.flink.streaming.api.TimeCharacteristic
import org.apache.flink.streaming.api.functions.timestamps.BoundedOutOfOrdernessTimestampExtractor
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.streaming.api.windowing.time.Time
import org.apache.flink.table.api.{EnvironmentSettings, Slide, Table, Tumble}
import org.apache.flink.table.api.scala.StreamTableEnvironment
import org.apache.flink.types.Row
import sun.plugin2.jvm.CircularByteBuffer.Streamer

//Table api 使用窗口
object FlinkTableTest4 {
  def main(args: Array[String]): Unit = {
    val env: StreamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment
    import org.apache.flink.streaming.api.scala._
    env.setParallelism(1)
    env.setStreamTimeCharacteristic(TimeCharacteristic.EventTime)
    val settings = EnvironmentSettings.newInstance().inStreamingMode().useOldPlanner().build()
    val tableEnv: StreamTableEnvironment = StreamTableEnvironment.create(env,settings)

    //读取socket中数据
    val ds1: DataStream[String] = env.socketTextStream("mynode5",9999)

    val ds2: DataStream[StationLog] = ds1.map(line => {
      val arr: Array[String] = line.split(",")
      StationLog(arr(0), arr(1), arr(2), arr(3), arr(4).toLong, arr(5).toLong)
    }).assignTimestampsAndWatermarks(new BoundedOutOfOrdernessTimestampExtractor[StationLog](Time.seconds(3)) {
      override def extractTimestamp(element: StationLog): Long = element.callTime
    })

    //转换成Table 对象
    import org.apache.flink.table.api.scala._
    val table1: Table = tableEnv.fromDataStream(ds2,'station_id,'call_out,'call_in,'call_type,'call_time.rowtime,'call_dur)

    //对Table 对象使用 窗口操作
    val table2: Table =
//      table1.window(Slide.over("10.second").every("5.second").on('call_time).as("window"))
      table1.window(Slide over "10.second" every "5.second" on 'call_time as "window")
//      table1.window(Tumble.over("5.second").on('call_time).as('window))
//      table1.window(Tumble over "5.second" on 'call_time as 'window )
      .groupBy('window, 'station_id)
      .select('window.start, 'window.end, 'station_id, 'call_dur.sum)

    //转换成DataStream
    tableEnv.toRetractStream[Row](table2).filter(tp=>{tp._1.equals(true)}).map(tp=>{tp._2}).print()

    env.execute()

  }

}
