package com.bjsxt.scalaflinkcode.flinksqltest

import org.apache.flink.api.common.typeinfo.TypeInformation
import org.apache.flink.api.scala.typeutils.Types
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.table.api.{EnvironmentSettings, Table}
import org.apache.flink.table.api.scala.StreamTableEnvironment
import org.apache.flink.table.functions.TableFunction
import org.apache.flink.types.Row

/**
  * 使用table api做wordcount
  */

//case class MyWC(word:String,count:Int)

case class MyFlinkFun() extends TableFunction[Row]{
  def eval(str:String): Unit ={
    str.split(" ").foreach(word=>{
      val row = new Row(2)
      row.setField(0,word)
      row.setField(1,1)
      collect(row)
    })
  }
  override def getResultType: TypeInformation[Row] = {
    Types.ROW(Types.STRING, Types.INT)
  }

}

object FlinkTableTest3 {
  def main(args: Array[String]): Unit = {
    val env: StreamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment
    import org.apache.flink.streaming.api.scala._
    val settings = EnvironmentSettings.newInstance().inStreamingMode().useOldPlanner().build()
    val tableEnv: StreamTableEnvironment = StreamTableEnvironment.create(env,settings)

    //读取socket中数据
    val ds1: DataStream[String] = env.socketTextStream("mynode5",9999)

    //将DS直接转换成Table 对象
    import org.apache.flink.table.api.scala._
    val table1: Table = tableEnv.fromDataStream(ds1,'str)

    //Flink中实现自定义函数
    val myFlinkFun = new MyFlinkFun()
    //使用自定义函数实现 切分单词
    val table2: Table = table1.flatMap(myFlinkFun('str)).as('word,'count)
      .groupBy('word)
      .select('word, 'count.sum)

    val resutlDS: DataStream[(Boolean, Row)] = tableEnv.toRetractStream[Row](table2)
    resutlDS.print()
    env.execute()

  }

}
