package com.bjsxt.scalaflinkcode.transformations

import com.bjsxt.scalaflinkcode.sources.StationLog
import org.apache.flink.api.common.state.{ValueState, ValueStateDescriptor}
import org.apache.flink.shaded.netty4.io.netty.handler.codec.http2.Http2Exception.StreamException
import org.apache.flink.streaming.api.functions.KeyedProcessFunction
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.util.Collector

/**
  * 如果一个通话在5s内 没有成功，发出警告信息
  */
object CallInfoWarning {
  def main(args: Array[String]): Unit = {
    val env: StreamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment
    import org.apache.flink.streaming.api.scala._
    val ds: DataStream[String] = env.socketTextStream("mynode5",9999)

    val stationDS: DataStream[StationLog] = ds.map(line => {
      val arr: Array[String] = line.split(",")
      StationLog(arr(0), arr(1), arr(2), arr(3), arr(4).toLong, arr(5).toLong)
    })

    val result: DataStream[String] = stationDS.keyBy(_.callOut).process(new KeyedProcessFunction[String, StationLog, String] {
      //定义状态，存储时间，注意：这里的每个key都会对应一个状态。
      private lazy val timeState: ValueState[Long] = getRuntimeContext.getState(new ValueStateDescriptor[Long]("timeState", classOf[Long]))

      //每条数据都会执行 ，value : 当前近来的这条数据，ctx :Flink 上下文 ，out : 回收结果对象
      override def processElement(value: StationLog, ctx: KeyedProcessFunction[String, StationLog, String]#Context, out: Collector[String]): Unit = {
        //获取当前本条数据的处理时间
        val currentProduceTime: Long = ctx.timerService().currentProcessingTime()
        //触发定时器的时间
        var trgTime = currentProduceTime + 5000

        if (!"success".equals(value.callType) && timeState.value() == 0) {
          //通话状态不成功，需要给当前的手机号设置定时器 5s后触发定时器
          ctx.timerService().registerProcessingTimeTimer(trgTime)
          //更新状态值
          timeState.update(trgTime)
        } else if ("success".equals(value.callType)) {
          //通话成功，删除定时器
          ctx.timerService().deleteProcessingTimeTimer(timeState.value())
          //清空当前key的状态
          timeState.clear()
        }
      }

      //定时器触发时，调用的方法
      override def onTimer(timestamp: Long, ctx: KeyedProcessFunction[String, StationLog, String]#OnTimerContext, out: Collector[String]): Unit = {
        //触发定时器逻辑：返回警告的信息
        out.collect(s"${ctx.getCurrentKey}连续呼叫5s 不成功")
        //清空当前key的状态
        timeState.clear()
      }
    })

    result.print()

    env.execute()



  }

}
