package com.bjsxt.scalaflinkcode.sources

import org.apache.flink.streaming.api.functions.source.{ParallelSourceFunction, SourceFunction}
import org.apache.flink.streaming.api.scala.{DataStream, StreamExecutionEnvironment}

import scala.util.Random

/**
  * 自定义并行source
  */
object SelfDefinedParalleSource {
  def main(args: Array[String]): Unit = {
    val env: StreamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment
    import org.apache.flink.streaming.api.scala._
    val ds: DataStream[StationLog] = env.addSource(new ParallelSourceFunction[StationLog] {
      var stop = false

      //产生数据，一般一个死循环来产生数据
      override def run(ctx: SourceFunction.SourceContext[StationLog]): Unit = {
        val random = new Random()
        val array = Array[String]("success", "fail", "barring", "busy")
        while (!stop) {
          1.to(10).map(one => {
            val sl = StationLog("sid_" + one, "181" + random.nextInt(10000000).formatted("%08d"),
              "191" + random.nextInt(10000000).formatted("%08d"), array(random.nextInt(4)), System.currentTimeMillis(), random.nextInt(100))

            //发送数据
            ctx.collect(sl)
          })
          Thread.sleep(1000 * 10)

        }
      }

      //当程序被取消时调用
      override def cancel(): Unit = {
        stop = true
      }
    })

    ds.print()
    env.execute()
  }
}
