package com.bjsxt.scalaflinkcode.sources

import org.apache.flink.streaming.api.scala.{DataStream, StreamExecutionEnvironment}

/**
  * Flink 读取集合数据 获取DataStream
  */

case class StationLog(sid:String,callOut:String,callIn:String,callType:String,callTime:Long,dur:Long)

object FinkSourceCollections {
  def main(args: Array[String]): Unit = {
    val env: StreamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment
    env.setParallelism(1)
    import org.apache.flink.streaming.api.scala._
    val stationDS: DataStream[String] = env.fromCollection(Array[String](
      "sid_1,18100001111,19100002226,success,1111,10",
      "sid_2,18100001112,19100002227,success,1112221,11",
      "sid_3,18100001113,19100002228,success,3333,12",
      "sid_4,18100001114,19100002229,success,11444111,13",
      "sid_5,18100001115,19100002210,success,5555,14"
    ))
    val result: DataStream[StationLog] = stationDS.map(line => {
      val arr: Array[String] = line.split(",")
      StationLog(arr(0), arr(1), arr(2), arr(3), arr(4).toLong, arr(5).toLong)
    })
    result.print()
    env.execute()
  }

}
