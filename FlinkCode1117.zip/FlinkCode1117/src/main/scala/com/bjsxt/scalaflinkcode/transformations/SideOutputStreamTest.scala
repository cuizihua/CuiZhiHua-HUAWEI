package com.bjsxt.scalaflinkcode.transformations

import com.bjsxt.scalaflinkcode.sources.{MyDefinedSource, StationLog}
import org.apache.flink.streaming.api.functions.ProcessFunction
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.util.Collector

/**
  * 侧输出流
  * 案例：将通话成功与通话不成功的数据分开处理
  */
object SideOutputStreamTest {
  def main(args: Array[String]): Unit = {
    val env: StreamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment
    import org.apache.flink.streaming.api.scala._
//    val ds: DataStream[String] = env.socketTextStream("mynode5",9999)
//  val stationDS: DataStream[StationLog] = ds.map(line => {
//    val arr: Array[String] = line.split(",")
//    StationLog(arr(0), arr(1), arr(2), arr(3), arr(4).toLong, arr(5).toLong)
//  })

    val stationDS: DataStream[StationLog] = env.addSource(new MyDefinedSource())

    val tag: OutputTag[StationLog] = new OutputTag[StationLog]("side-output")

    val result: DataStream[StationLog] = stationDS.process(new ProcessFunction[StationLog, StationLog] {
      //value : 当前数据本身，ctx : Flink 上下文 out: 回收数据对象
      override def processElement(value: StationLog, ctx: ProcessFunction[StationLog, StationLog]#Context, out: Collector[StationLog]): Unit = {
        if (value.callType.equals("success")) {
          out.collect(value)
        } else {
          //对于不成功的数据，可以放入侧输出流中
          ctx.output(tag, value)
        }
      }
    })
    //result中存放的是  通话成功数据
    result.print("主流：")
    //打印通话不成功的数据
    result.getSideOutput(tag).print("侧流：")

    env.execute()
  }

}
