package com.bjsxt.scalaflinkcode.Time

import com.bjsxt.scalaflinkcode.sources.StationLog
import org.apache.flink.api.common.functions.ReduceFunction
import org.apache.flink.streaming.api.TimeCharacteristic
import org.apache.flink.streaming.api.functions.AssignerWithPunctuatedWatermarks
import org.apache.flink.streaming.api.functions.timestamps.BoundedOutOfOrdernessTimestampExtractor
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.streaming.api.watermark.Watermark
import org.apache.flink.streaming.api.windowing.time.Time

/**
  *  非周期性引入watermark，使用场景：当数据产生只有某一类数据有延迟，可以使用非周期引入watermark
  *  需求：
  *   统计每个基站每5s 通话总时长。输入基站 sid_7才统计watermark ,其他基站不生成watermark
  */
object FlinkWaterMarkTest3 {
  def main(args: Array[String]): Unit = {
    val env: StreamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment
    import org.apache.flink.streaming.api.scala._
    //并行度设置为1
    env.setParallelism(1)
    //指定使用事件时间
    env.setStreamTimeCharacteristic(TimeCharacteristic.EventTime)

    val ds: DataStream[String] = env.socketTextStream("mynode5",9999)
    val ds2: DataStream[StationLog] = ds.map(line => {
      val arr: Array[String] = line.split(",")
      StationLog(arr(0), arr(1), arr(2), arr(3), arr(4).toLong, arr(5).toLong)
    })
    //设置watermark
    val ds3 = ds2.assignTimestampsAndWatermarks(new AssignerWithPunctuatedWatermarks[StationLog] {
      /**
        * 检查是否生成下个watermark。lastElement：上一个事件的事件时间 ，extractedTimestamp ： 上一次抽取到的事件时间
        * 逻辑：如果当前事件基站ID 为sid7 时，生成watermark,否则不生成watermark
        */

      override def checkAndGetNextWatermark(lastElement: StationLog, extractedTimestamp: Long): Watermark = {
        if(lastElement.sid.equals("sid_7")){
          //根据当前事件的时间，生成watermark
//          val maxEventTime = lastElement.callTime.max(extractedTimestamp)
          new Watermark(extractedTimestamp-3000)
        }else{
          //不生成watermark
          null
        }
      }

      //指定事件时间 element : 当前事件，previousElementTimestamp：前一个事件的时间戳
      override def extractTimestamp(element: StationLog, previousElementTimestamp: Long): Long = {
        element.callTime
      }
    })


    //对ds3使用window
    val result: DataStream[StationLog] = ds3.keyBy(_.sid)
      .timeWindow(Time.seconds(5))
      .reduce(new ReduceFunction[StationLog] {
        override def reduce(value1: StationLog, value2: StationLog): StationLog = {
          StationLog(value1.sid, value1.callOut, value1.callIn, value1.callType, value1.callTime, value1.dur + value2.dur)
        }
      })
    result.print()

    env.execute()
  }
}
