package com.bjsxt.scalaflinkcode.windows

import com.bjsxt.scalaflinkcode.sources.StationLog
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.streaming.api.windowing.assigners.{ProcessingTimeSessionWindows, TumblingProcessingTimeWindows}
import org.apache.flink.streaming.api.windowing.time.Time
import org.apache.flink.streaming.api.windowing.windows.TimeWindow

/**
  * session window - 会话窗口：
  *
  *   Flink 读取socket 数据，如果连续5s内没有输入数据，生成窗口统计输入数据总条数
  */
object SessionWindowTest {
  def main(args: Array[String]): Unit = {
    val env: StreamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment
    import org.apache.flink.streaming.api.scala._
    val lines: DataStream[String] = env.socketTextStream("mynode5",9999)
    val stationDS: DataStream[(String, Int)] = lines.map((_,1))

//    val stationDS: DataStream[StationLog] = lines.map(line => {
//      val arr: Array[String] = line.split(",")
//      StationLog(arr(0), arr(1), arr(2), arr(3), arr(4).toLong, arr(5).toLong)
//    })


    //会话窗口
    stationDS.keyBy(0)
      .window(ProcessingTimeSessionWindows.withGap(Time.seconds(5)))
      .sum(1)
      .print()


    //滑动窗口
//    stationDS.keyBy(_.sid).timeWindow(Time.seconds(10),Time.seconds(5)).sum("dur").print()


    //滚动窗口，每隔5s统计每个基站的总通话时长
//    stationDS.keyBy(_.sid).timeWindow(Time.seconds(5)).sum("dur").print()

    env.execute()









    //滑动窗口
//    lines.timeWindowAll(Time.seconds(10),Time.seconds(5))
//        .reduce((s1,s2)=>{s1+"#"+s2}).print()

    //时间滚动窗口
//    lines.timeWindowAll(Time.seconds(5)).reduce((s1,s2)=>{s1+"#"+s2}).print()
//    lines.windowAll(TumblingProcessingTimeWindows.of(Time.seconds(5)))

    //session 会话窗口
//    lines.windowAll(ProcessingTimeSessionWindows.withGap(Time.seconds(5)))
//      .reduce((s1,s2)=>{s1+"#"+s2})
//      .print()

//    env.execute()

  }

}
