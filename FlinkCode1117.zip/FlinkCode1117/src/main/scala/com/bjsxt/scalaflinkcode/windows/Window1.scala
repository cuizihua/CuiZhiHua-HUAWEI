package com.bjsxt.scalaflinkcode.windows

import org.apache.flink.api.java.tuple.Tuple
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.streaming.api.windowing.assigners.TumblingProcessingTimeWindows
import org.apache.flink.streaming.api.windowing.time.Time
import org.apache.flink.streaming.api.windowing.windows.TimeWindow

/**
  * 窗口操作
  *   滚动窗口：
  */
object Window1Test {

  def main(args: Array[String]): Unit = {
    val env: StreamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment
    import org.apache.flink.streaming.api.scala._
    val lines: DataStream[String] = env.socketTextStream("mynode5",9999)


//    lines.timeWindowAll(Time.seconds(5)).reduce((s1,s2)=>{s1+"#"+s2}).print()

//    val result: AllWindowedStream[String, TimeWindow] = lines.windowAll(TumblingProcessingTimeWindows.of(Time.seconds(5)))
//    result.reduce((s1,s2)=>{s1+"$"+s2}).print()


//    val keyedDs: KeyedStream[(String, Int), Tuple] = lines.flatMap(line => {
//      line.split(" ")
//    }).map((_, 1))
//      .keyBy(0)

//    keyedDs
//        .timeWindow(Time.seconds(10),Time.seconds(5))
//      .window(TumblingProcessingTimeWindows.of(Time.seconds(5)))
//      .sum(1).print()

    env.execute()

  }
}
