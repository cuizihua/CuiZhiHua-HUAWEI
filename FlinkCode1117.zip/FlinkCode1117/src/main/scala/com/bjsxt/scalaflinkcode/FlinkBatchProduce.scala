package com.bjsxt.scalaflinkcode

import org.apache.flink.api.scala.{AggregateDataSet, DataSet, ExecutionEnvironment, GroupedDataSet}

/**
  *  Flink读取文件
  *  1.Flink 批处理底层对象是DataSet
  *  2.Flink 不是面向K,V格式编程
  */
case class MyWC(word:String,count:Int)
object FlinkBatchProduce {
  def main(args: Array[String]): Unit = {
    import org.apache.flink.api.scala._
    //1.创建Flink的执行环境
    val env: ExecutionEnvironment = ExecutionEnvironment.getExecutionEnvironment
    //2.读取文件
    val lines: DataSet[String] = env.readTextFile("./data/words")

    val words: DataSet[String] = lines.flatMap(line=>{line.split(" ")})

    val myds1: DataSet[MyWC] = words.map(word=>{MyWC(word,1)})

//    myds1.groupBy(0).sum(1).print()
    myds1.groupBy("word").sum("count").print()


//    val ds2: GroupedDataSet[MyWC] = myds1.groupBy(mc=>{mc.word})
//    val result: DataSet[MyWC] = ds2.reduce((mc1: MyWC, mc2: MyWC) => {
//      MyWC(mc1.word, mc1.count + mc2.count)
//    })
//    result.print()




//    //3.对每行数据进行切分
//    val words: DataSet[String] = lines.flatMap(line=>{line.split(" ")})
//    //4.对单词进行计数
//    val pairWords: DataSet[(String, Int,Int)] = words.map(word=>{(word,1,1)})
//    //5.对单词进行分组
//    val groupDS: GroupedDataSet[(String, Int,Int)] = pairWords.groupBy(0)
//    //6.对数据进行聚合
//    val sumDS: AggregateDataSet[(String, Int,Int)] = groupDS.sum(1)
//    //7.打印结果
//    sumDS.print()
  }
}
