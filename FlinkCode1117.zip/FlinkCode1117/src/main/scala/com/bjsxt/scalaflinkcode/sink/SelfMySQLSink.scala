package com.bjsxt.scalaflinkcode.sink

import java.sql.{Connection, DriverManager, PreparedStatement}

import com.bjsxt.scalaflinkcode.sources.StationLog
import org.apache.flink.configuration.Configuration
import org.apache.flink.shaded.netty4.io.netty.handler.codec.http2.Http2Exception.StreamException
import org.apache.flink.streaming.api.functions.sink.{RichSinkFunction, SinkFunction}
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment

/**
  * 将数据写往 MySQL
  */
class DefinedMySQLSink extends RichSinkFunction[StationLog]{
  //定义全局变量
  var conn:Connection = _
  var pst : PreparedStatement= _

  //当初始化Sink时调用一次
  override def open(parameters: Configuration): Unit = {
    conn = DriverManager.getConnection("jdbc:mysql://192.168.179.14:3306/flinktest","root","123456")
    pst = conn.prepareStatement("insert into station_info values (?,?,?,?,?,?)")

  }


  //当来一条数据后执行一次
  override def invoke(value: StationLog, context: SinkFunction.Context[_]): Unit = {
    val sid: String = value.sid
    val out: String = value.callOut
    val in: String = value.callIn
    val callType: String = value.callType
    val time: Long = value.callTime
    val dur: Long = value.dur
    pst.setString(1,sid)
    pst.setString(2,out)
    pst.setString(3,in)
    pst.setString(4,callType)
    pst.setLong(5,time)
    pst.setLong(6,dur)
    pst.executeUpdate()
  }

  //当取消任务时执行一次
  override def close(): Unit ={
    pst.close()
    conn.close()
  }
}

object SelfMySQLSink {
  def main(args: Array[String]): Unit = {
    val env: StreamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment
    import org.apache.flink.streaming.api.scala._

    val lines: DataStream[String] = env.socketTextStream("mynode5",9999)
    val result: DataStream[StationLog] = lines.map(line => {
      val arr: Array[String] = line.split(",")
      StationLog(arr(0), arr(1), arr(2), arr(3), arr(4).toLong, arr(5).toLong)
    })


    //设置mysql sink
    result.addSink(new DefinedMySQLSink())
    env.execute()
  }
}
