package com.bjsxt.scalaflinkcode.sink

import java.lang
import java.util.Properties

import org.apache.flink.api.common.serialization.SimpleStringSchema
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaProducer.Semantic
import org.apache.flink.streaming.connectors.kafka.{FlinkKafkaConsumer, FlinkKafkaProducer, KafkaSerializationSchema}
import org.apache.kafka.clients.producer.ProducerRecord
import org.apache.kafka.common.serialization.{ByteArraySerializer, StringSerializer}
import org.codehaus.jackson.map.deser.std.StringDeserializer

/**
  * 从Kafka中读取数据将数据写往kafka
  */
object SelfKafkaSinkTest {
  def main(args: Array[String]): Unit = {
    val env: StreamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment
    import  org.apache.flink.streaming.api.scala._

    //设置Kafka l连接参数
    val props = new Properties()
    props.setProperty("bootstrap.servers","mynode1:9092,mynode2:9092,mynode3:9092")
    props.setProperty("key.deserializer",classOf[StringDeserializer].getName)
    props.setProperty("value.deserializer",classOf[StringDeserializer].getName)
    props.setProperty("group.id","group11191653")
    //从Kafka 读取数据做单词统计
    val lines: DataStream[String] = env.addSource(new FlinkKafkaConsumer[String]("flinktest1",new SimpleStringSchema(),props))

    //统计单词技术
    val ds: DataStream[(String, Int)] = lines.flatMap(_.split(" "))
      .map((_, 1))
      .keyBy(0)
      .sum(1)

    //将结果保存到Kafka中
    val result: DataStream[(String,String)] = ds.map(tp => {
      ("",tp._1 + "_" + tp._2)
    })

    //sink 数据到Kafka中的配置
    val props1 = new Properties()
    props1.setProperty("bootstrap.servers","mynode1:9092,mynode2:9092,mynode3:9092")
    props1.setProperty("key.serializer",classOf[ByteArraySerializer].getName)
    props1.setProperty("value.serializer",classOf[ByteArraySerializer].getName)

    //将key ,value 格式数据写往Kafka中

    val kafkaSink: FlinkKafkaProducer[(String, String)] = new FlinkKafkaProducer[(String, String)]("testtopic",
      new KafkaSerializationSchema[(String, String)] {
        override def serialize(element: (String, String), timestamp: lang.Long): ProducerRecord[Array[Byte], Array[Byte]] =
          new ProducerRecord[Array[Byte], Array[Byte]]("testtopic", element._1.getBytes(), element._2.getBytes())
      },
      props1,
      Semantic.EXACTLY_ONCE)

    //sink
    result.addSink(kafkaSink)
    env.execute()


  }
}
