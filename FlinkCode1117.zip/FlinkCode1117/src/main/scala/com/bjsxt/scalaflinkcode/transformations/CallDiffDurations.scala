package com.bjsxt.scalaflinkcode.transformations

import com.bjsxt.scalaflinkcode.sources.StationLog
import org.apache.flink.api.common.state.{ValueState, ValueStateDescriptor}
import org.apache.flink.streaming.api.functions.KeyedProcessFunction
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.util.Collector

/**
  * 统计基站两次通话的间隔时长
  */
object CallDiffDurations {
  def main(args: Array[String]): Unit = {
    val env: StreamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment
    import org.apache.flink.streaming.api.scala._
    val ds: DataStream[String] = env.socketTextStream("mynode5",9999)
    val stationDS: DataStream[StationLog] = ds.map(line => {
      val arr: Array[String] = line.split(",")
      StationLog(arr(0), arr(1), arr(2), arr(3), arr(4).toLong, arr(5).toLong)
    })

    /**
      * 管理状态实现2
      *   sl:进入数据的类型
      *   option: 当前key 对应的上一次保存的状态值
      *   返回类型 ： （返回结果类型，返回当前key的状态）
      */

    stationDS.keyBy(_.sid).mapWithState((sl:StationLog,option:Option[Long])=>{
      if(option.isEmpty){
        //没有状态
        (s"第一次处理 ${sl}",Option(sl.callTime))
      }else{
        //有状态，获取状态
        val preCallTime: Long = option.get
        (s"基站${sl.sid} 两次通话的间隔:${sl.callTime - preCallTime}",Option(sl.callTime))
      }

    }).print()
    env.execute()


    //管理状态实现1
//    stationDS.keyBy(_.sid).process(new KeyedProcessFunction[String,StationLog,String] {
//      //给每个基站设置一个状态，状态中存储的是上一条数据的通话时间
//      private lazy val timeState: ValueState[Long] = getRuntimeContext.getState(new ValueStateDescriptor[Long]("timeState",classOf[Long]))
//      override def processElement(value: StationLog, ctx: KeyedProcessFunction[String, StationLog, String]#Context, out: Collector[String]): Unit = {
//        if(timeState.value() == 0){
//          //没有状态，更新状态
//          timeState.update(value.callTime)
//        }else{
//          val preCallTime: Long = timeState.value()
//          val currentCallTime: Long = value.callTime
//          timeState.update(currentCallTime)
//          out.collect(s"当前基站：${value.sid},两次通话的间隔时长为:${currentCallTime - preCallTime}")
//        }
//      }
//    }).print()

//    env.execute()

  }

}
