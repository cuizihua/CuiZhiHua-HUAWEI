package com.bjsxt.scalaflinkcode.transformations

import com.bjsxt.scalaflinkcode.sources.StationLog
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment

object Aggregations {
  def main(args: Array[String]): Unit = {
    val env: StreamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment
    env.setParallelism(1)
    import org.apache.flink.streaming.api.scala._
    val lines: DataStream[StationLog] = env.fromCollection(Array[StationLog](
      StationLog("sid_6", "18100000001", "19100001111", "success", 1605770302423L, 30L),
      StationLog("sid_6", "18100000002", "19100001112", "success", 1605770302423L, 5L),
      StationLog("sid_6", "18100000001", "19100001113", "success", 1605770302423L, 20L),
      StationLog("sid_6", "18100000002", "19100001114", "success", 1605770302423L, 50L),
      StationLog("sid_6", "18100000001", "19100001115", "success", 1605770302423L, 100L),
      StationLog("sid_6", "18100000002", "19100001116", "success", 1605770302423L, 200L)
    ))

    //统计每个主叫最小通话时长
    lines.keyBy(_.callOut).minBy(5).print()
    env.execute()

    //统计每个主叫通话总时长
//    lines.keyBy(_.callOut).sum(5).map(sl=>(sl.callOut,sl.dur)).print()
//    env.execute()

  }

}
