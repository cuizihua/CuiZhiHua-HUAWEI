package com.bjsxt.scalaflinkcode.transformations

import java.util

import com.bjsxt.scalaflinkcode.sources.StationLog
import org.apache.flink.api.common.state.{ListState, ListStateDescriptor}
import org.apache.flink.streaming.api.functions.KeyedProcessFunction
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.util.Collector

/**
  *  统计每个号码 每次通话的最近20s内两两通话间隔
  */
object CallDurTest {
  def main(args: Array[String]): Unit = {
    val env: StreamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment
    import org.apache.flink.streaming.api.scala._
    val ds: DataStream[String] = env.socketTextStream("mynode5",9999)
    val stationDS: DataStream[StationLog] = ds.map(line => {
      val arr: Array[String] = line.split(",")
      StationLog(arr(0), arr(1), arr(2), arr(3), arr(4).toLong, arr(5).toLong)
    })

    stationDS.keyBy(_.callOut).process(new KeyedProcessFunction[String,StationLog,String] {

      //创建ListState 状态管理每个key的状态
      private lazy val callTimeState: ListState[Long] = getRuntimeContext.getListState(new ListStateDescriptor[Long]("callTimeState",classOf[Long]))

      override def processElement(value: StationLog, ctx: KeyedProcessFunction[String, StationLog, String]#Context, out: Collector[String]): Unit = {
        //获取当前此条数据处理的时间
        val currentTime: Long = ctx.timerService().currentProcessingTime()
        //每次进入数据之后，都注册定时器
        ctx.timerService().registerProcessingTimeTimer(currentTime+20*1000)
        //将当前这条数据的 callTime 保存到状态中
        callTimeState.add(value.callTime)
      }

      //触发定时器
      override def onTimer(timestamp: Long, ctx: KeyedProcessFunction[String, StationLog, String]#OnTimerContext, out: Collector[String]): Unit = {
        //创建返回的值
        val str = new StringBuilder
        //从状态中获取值
        val iter: util.Iterator[Long] = callTimeState.get().iterator()

        var flag = 1
        var preCallTime = 0L
        while(iter.hasNext){
          val currentOne: Long = iter.next()
          if(flag == 1){
            //第一次
            str.append(s"第${flag}次统计,时长：${currentOne},")
          }else{
            str.append(s"两次相差的时长：${currentOne - preCallTime},")
          }
          preCallTime = currentOne
          flag +=1
        }

        out.collect(s"当前手机号 ：${ctx.getCurrentKey},信息：${str.substring(0,str.length-1)}")
      }
    }).print()

    env.execute()

  }

}
