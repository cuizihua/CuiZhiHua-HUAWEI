package com.bjsxt.scalaflinkcode.windows

import com.bjsxt.scalaflinkcode.sources.StationLog
import org.apache.flink.api.common.functions.AggregateFunction
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.streaming.api.scala.function.WindowFunction
import org.apache.flink.streaming.api.windowing.time.Time
import org.apache.flink.streaming.api.windowing.windows.TimeWindow
import org.apache.flink.util.Collector

/**
  * 每隔5s 统计最近10s ，统计每个基站的通话总条数
  */
object AggregateTest {
  def main(args: Array[String]): Unit = {
    val env: StreamExecutionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment
    import org.apache.flink.streaming.api.scala._
    val lines: DataStream[String] = env.socketTextStream("mynode5",9999)

    val stationDS: DataStream[StationLog] = lines.map(line => {
      val arr: Array[String] = line.split(",")
      StationLog(arr(0), arr(1), arr(2), arr(3), arr(4).toLong, arr(5).toLong)
    })

    //使用aggreagte 处理窗口数据
    val result = stationDS.keyBy(_.sid)
      .timeWindow(Time.seconds(10), Time.seconds(5))
      .aggregate(new AggregateFunction[StationLog, (String, Long), (String, Long)] {
        //给每个key 做初始化的值
        override def createAccumulator(): (String, Long) = ("", 0L)

        //在每个key 的分区内进行累加
        override def add(value: StationLog, accumulator: (String, Long)): (String, Long) = (value.sid, accumulator._2 + 1)

        //针对不同分区内的相同key的数据进行累加处理
        override def merge(a: (String, Long), b: (String, Long)): (String, Long) = (a._1, (a._2 + b._2))

        //获取结果
        override def getResult(accumulator: (String, Long)): (String, Long) = accumulator
      },
        new WindowFunction[(String,Long),String,String,TimeWindow] {
          override def apply(key: String, window: TimeWindow, input: Iterable[(String, Long)], out: Collector[String]): Unit = {
            out.collect(s"基站：${key} ,窗口起始时间：${window.getStart} - ${window.getEnd},当前基站通话时长：${input.last}")
          }
        })

    result.print()
    env.execute()
  }

}
